[
    {
        "title": "vedio 1",
        "vedio_link": "https://player.vimeo.com/video/822213540",
        "description": "Lesson description",
        "thimble": "https://media.istockphoto.com/id/1486039885/photo/young-son-giving-father-christmas-present-hug-and-kiss.jpg?s=1024x1024&w=is&k=20&c=eH0dymatcJd-7L9U2bkrH-y3imtMSbeqDjO6Xf516ik=",
        "status": "active",
        "tag": ["tag1", "tag2"],
        "course": "64a161162b9284f84f7927cd",
        "courseId": "005"
    },
    {
        "title": "vedio 2",
        "vedio_link": "https://player.vimeo.com/video/822213541",
        "description": "Lesson description",
        "thimble": "https://media.istockphoto.com/id/1486039885/photo/young-son-giving-father-christmas-present-hug-and-kiss.jpg?s=1024x1024&w=is&k=20&c=eH0dymatcJd-7L9U2bkrH-y3imtMSbeqDjO6Xf516ik=",
        "status": "active",
        "tag": ["tag1", "tag2"],
        "course": "64a160f82b9284f84f7927c8",
        "courseId": "005"
    },
    {
        "title": "vedio 3",
        "vedio_link": "https://player.vimeo.com/video/822213544",
        "description": "Lesson description",
        "thimble": "https://media.istockphoto.com/id/1486039885/photo/young-son-giving-father-christmas-present-hug-and-kiss.jpg?s=1024x1024&w=is&k=20&c=eH0dymatcJd-7L9U2bkrH-y3imtMSbeqDjO6Xf516ik=",
        "status": "active",
        "tag": ["tag1", "tag2"],
        "course": "64a160f82b9284f84f7927c8",
        "courseId": "005"
    },
    {
        "title": "vedio 4",
        "vedio_link": "https://player.vimeo.com/video/822213545",
        "description": "Lesson description",
        "thimble": "https://media.istockphoto.com/id/1486039885/photo/young-son-giving-father-christmas-present-hug-and-kiss.jpg?s=1024x1024&w=is&k=20&c=eH0dymatcJd-7L9U2bkrH-y3imtMSbeqDjO6Xf516ik=",
        "status": "active",
        "tag": ["tag1", "tag2"],
        "course": "64a160f82b9284f84f7927c8",
        "courseId": "005"
    },
    {
        "title": "vedio 5",
        "vedio_link": "https://player.vimeo.com/video/822213546",
        "description": "Lesson description",
        "thimble": "https://media.istockphoto.com/id/1486039885/photo/young-son-giving-father-christmas-present-hug-and-kiss.jpg?s=1024x1024&w=is&k=20&c=eH0dymatcJd-7L9U2bkrH-y3imtMSbeqDjO6Xf516ik=",
        "status": "active",
        "tag": ["tag1", "tag2"],
        "course": "64a160f82b9284f84f7927c8",
        "courseId": "005"
    },
    {
        "title": "vedio 6",
        "vedio_link": "https://player.vimeo.com/video/822213547",
        "description": "Lesson description",
        "thimble": "https://media.istockphoto.com/id/1486039885/photo/young-son-giving-father-christmas-present-hug-and-kiss.jpg?s=1024x1024&w=is&k=20&c=eH0dymatcJd-7L9U2bkrH-y3imtMSbeqDjO6Xf516ik=",
        "status": "active",
        "tag": ["tag1", "tag2"],
        "course": "64a160f82b9284f84f7927c8",
        "courseId": "005"
    }
]



[

    {
        "quizList": [
            {
                "title": "Which of the following is not a primitive data type in JavaScript?",
                "serial_no": 1,
                "answers": [
                    "Number",
                    "String",
                    "Boolean"
                ],
                "correct_answer": "Number",
                "tag": [
                    "Tag 1",
                    "Tag 2"
                ],
                "hint": "Hint 1"
            },
            {
                "title": "What does the “typeof” operator do in JavaScript?",
                "serial_no": 2,
                "answers": [
                    "Returns the data type of a variable",
                    "Checks if a variable is defined",
                    "Assigns a value to a variable",
                    "Concatenates two strings"
                ],
                "correct_answer": "Returns the data type of a variable",
                "tag": [
                    "Tag 3"
                ],
                "hint": "Hint 2"
            },
            {
                "title": "Question 3 What does the “typeof” operator do in JavaScript?",
                "serial_no": 3,
                "answers": [
                    "Question 3 Returns the data type of a variable",
                    "Question 3 Checks if a variable is defined",
                    "Question 3 Assigns a value to a variable",
                    "Concatenates two strings"
                ],
                "correct_answer": "Question 3 Assigns a value to a variable",
                "tag": [
                    "Tag 3"
                ],
                "hint": "Hint 2"
            },
            {
                "title": "Question 4 What does the “typeof” operator do in JavaScript?",
                "serial_no": 4,
                "answers": [
                    "Question 4 Returns the data type of a variable",
                    "Question 4 Checks if a variable is defined",
                    "Question 4 Assigns a value to a variable",
                    "Question 4 Concatenates two strings"
                ],
                "correct_answer": "Question 4 Concatenates two strings",
                "tag": [
                    "Tag 3"
                ],
                "hint": "Hint 2"
            }
        ],
        "status": "active",
        "course": "64a15fd92b9284f84f7927b8",
        "courseId": "001"
    }
]