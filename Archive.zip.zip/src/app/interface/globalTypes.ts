export type IStatus = 'active' | 'deactivate' | 'disabled' | 'block'|"save";
export type IGender = 'male' | 'female'|'other'