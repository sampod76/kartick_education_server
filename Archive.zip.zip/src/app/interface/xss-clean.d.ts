/* eslint-disable @typescript-eslint/ban-types */
declare module 'xss-clean' {
  const value: Function;

  export default value;
}
