declare module 'fcm-node' {
    const content: any; // You might need to replace `any` with the actual type of the module.
    export = content;
  }
  