export const PURCHASE_COURSE_SEARCHABLE_FIELDS = ['title', 'details', 'tags'];
export const PURCHASE_COURSE_FILTERABLE_FIELDS = [
  'searchTerm',
  'status',
  'select',
  'course',
  'delete',
  'type',
  'user',
];
