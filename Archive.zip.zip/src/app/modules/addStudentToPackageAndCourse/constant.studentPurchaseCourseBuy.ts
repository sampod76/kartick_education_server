export const student_purchase_course_SEARCHABLE_FIELDS = [
  'title',
  'details',
  'tags',
];
export const student_purchase_course_FILTERABLE_FIELDS = [
  'searchTerm',
  'status',
  'select',
  'course',
  'delete',
  'sellerPackage',
  'user',
  'author',
];
