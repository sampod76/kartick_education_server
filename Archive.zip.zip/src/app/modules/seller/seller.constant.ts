export const sellerFilterableFields = [
  'searchTerm',
  'id',
  'email',
  'status',
  'phoneNumber',
  'delete',
  "isDelete"
];

export const sellerSearchableFields = [
  'id',
  'email',
  'phoneNumber',
  'name.firstName',
  'name.lastName',

];
