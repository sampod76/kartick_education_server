export const skills_plan_SEARCHABLE_FIELDS = ['title'];
export const skills_plan_FILTERABLE_FIELDS = [
  'searchTerm',
  'status',
  'delete',
  'select',
  'page',
  'isDelete',
];

export const skills_plan_TYPES = ['free', 'paid', 'open', 'closed', 'recurrig'];
export const skills_plan_STATUS = ['active', 'deactivate', 'save'];
