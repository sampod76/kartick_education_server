export const trainerFilterableFields = [
  'searchTerm',
  'id',
  'email',
  'status',
  'phoneNumber',
];

export const trainerSearchableFields = [
  'id',
  'email',
  'phoneNumber',
  'name.firstName',
  'name.lastName',
  'delete'
];
