export const UserLoginHistorySearchableFields = ['id', 'email'];

export const UserLoginHistoryFilterableFields = ['searchTerm', 'user','isDelete'];
