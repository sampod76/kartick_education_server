export const Course_label_SEARCHABLE_FIELDS = ['title'];
export const Course_label_FILTERABLE_FIELDS = [
  'searchTerm',
  'title',
  'status',
  'delete',
  'children',
  'category',
  'serial_number',
  "isDelete"
];
