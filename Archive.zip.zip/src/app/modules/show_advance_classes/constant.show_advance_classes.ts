export const Show_advance_classes_SEARCHABLE_FIELDS = ['title'];
export const Show_advance_classes_FILTERABLE_FIELDS = [
  'searchTerm',
  'status',
  'delete',
  'select',
  'page',
  'isDelete',
];

export const Show_advance_classes_TYPES = ['free', 'paid', 'open', 'closed', 'recurrig'];
export const Show_advance_classes_STATUS = ['active', 'deactivate', 'save'];
