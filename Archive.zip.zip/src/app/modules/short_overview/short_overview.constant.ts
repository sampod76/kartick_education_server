export const Short_overview_SEARCHABLE_FIELDS = ['title'];
export const Short_overview_FILTERABLE_FIELDS = [
  'searchTerm',
  'status',
  'delete',
  'select',
  'page',
  'isDelete',
];

export const Short_overview_TYPES = ['free', 'paid', 'open', 'closed', 'recurrig'];
export const Short_overview_STATUS = ['active', 'deactivate', 'save'];
