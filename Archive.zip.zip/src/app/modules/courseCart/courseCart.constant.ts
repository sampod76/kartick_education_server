export const CourseCart_SEARCHABLE_FIELDS = [];
export const CourseCart_FILTERABLE_FIELDS = [
  'searchTerm',
  'status',
  'course',
  'user',
  'delete',
  'isDelete',
];
