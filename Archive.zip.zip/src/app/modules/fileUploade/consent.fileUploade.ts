export const FILEUPLOADE_SEARCHABLE_FIELDS = ['original_filename'];
export const FILEUPLOADE_FILTERABLE_FIELDS = ['searchTerm', 'category', 'user'];
