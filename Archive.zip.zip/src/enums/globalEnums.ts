export enum ENUM_STATUS {
  ACTIVE = 'active',
  DEACTIVATE = 'deactivate',
  SAVE = 'save',
  BLOCK = 'block'
}
export enum ENUM_YN {
  YES = 'yes',
  NO = 'no',
}

export enum ENUM_VIDEO_PLATFORM {
  VIMEO = 'vimeo',
  YOUTUBE = 'youtube',
  FACEBOOK = 'facebook',
}
