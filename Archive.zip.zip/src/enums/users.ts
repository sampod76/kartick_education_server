export enum ENUM_USER_ROLE {
  SUPER_ADMIN = 'superAdmin',
  ADMIN = 'admin',
  MODERATOR = 'moderator',
  STUDENT = 'student',
  TRAINER = 'trainer',
  TEACHER = 'teacher',
  SELLER = 'seller',
}
