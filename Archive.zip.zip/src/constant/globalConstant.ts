export const STATUS_ARRAY=['active', 'deactivate', 'save','disable',"block"]
export const GENDER_ARRAY= ['male', 'female',"other"]
export const YN_ARRAY=['yes','no']
