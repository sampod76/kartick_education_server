export const QUIZ_SUBMIT_SEARCHABLE_FIELDS = ['title', 'details',"tags"];
export const QUIZ_SUBMIT_FILTERABLE_FIELDS = ['searchTerm', 'status',"select","category","course","milestone","module","lesson",'delete','quiz'];
