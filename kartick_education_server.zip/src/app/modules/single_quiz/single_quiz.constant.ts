export const SINGLE_QUIZ_SEARCHABLE_FIELDS = ['title', 'details', 'tags'];
export const SINGLE_QUIZ_TYPE = ['input', 'select', 'multiple_select', 'text'];
export const SINGLE_QUIZ_FILTERABLE_FIELDS = [
  'searchTerm',
  'status',
  'select',
  'quiz',
  'delete',
];
