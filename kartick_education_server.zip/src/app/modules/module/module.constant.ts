export const MODULE_SEARCHABLE_FIELDS = ['title', 'details',"tags"];
export const MODULE_FILTERABLE_FIELDS = ['searchTerm', 'status',"select","category","milestone","course",'delete','lesson_quiz',"isDelete"]; //lesson_quiz=yes
