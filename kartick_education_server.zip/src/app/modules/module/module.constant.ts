export const MODULE_SEARCHABLE_FIELDS = ['title', 'details',"tags"];
export const MODULE_FILTERABLE_FIELDS = ['searchTerm', 'status',"select","milestone",'delete','lesson_quiz']; //lesson_quiz=yes
