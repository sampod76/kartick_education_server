export const userSearchableFields = ['email'];

export const userFilterableFields = ['searchTerm', 'role','delete','multipleRole'];
