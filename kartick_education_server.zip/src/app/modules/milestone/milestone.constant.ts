export const MILESTONE_SEARCHABLE_FIELDS = ['title', 'details',"tags"];
export const MILESTONE_FILTERABLE_FIELDS = ['searchTerm', 'status',"select","course",'delete',"module"];
