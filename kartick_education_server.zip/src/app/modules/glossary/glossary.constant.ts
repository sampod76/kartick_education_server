export const GLOSSARY_SEARCHABLE_FIELDS = [
    'title', 
// 'details',
"tags"
];
export const GLOSSARY_FILTERABLE_FIELDS = ['searchTerm', 'status',"select","module",'delete',"isDelete"];
