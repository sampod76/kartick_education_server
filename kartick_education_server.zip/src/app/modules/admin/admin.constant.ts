export const adminFilterableFields = [
  'searchTerm',
  'id',
  'bloodGroup',
  'email',
  'phoneNumber',
];

export const adminSearchableFields = [
  'id',
  'email',
  'phoneNumber',
  'name.firstName',
  'name.lastName',
  'delete',
  "select"
];
