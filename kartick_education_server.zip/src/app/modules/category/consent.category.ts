export const CATEGORY_SEARCHABLE_FIELDS = ['title'];
export const CATEGORY_FILTERABLE_FIELDS = [
  'searchTerm',
  'title',
  'status',
  'delete',
  'children',
];
