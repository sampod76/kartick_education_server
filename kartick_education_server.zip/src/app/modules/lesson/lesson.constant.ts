export const LESSON_SEARCHABLE_FIELDS = [
    'title', 
// 'details',
"tags"
];
export const LESSON_FILTERABLE_FIELDS = ['searchTerm', 'status',"select","category","course","milestone","module",'delete',"isDelete"];
