export const FILEUPLOADE_SEARCHABLE_FIELDS = [
  'title',
  'category',
  'tag',
  'filename',
];
export const FILEUPLOADE_FILTERABLE_FIELDS = ['searchTerm', 'category', 'tag'];
